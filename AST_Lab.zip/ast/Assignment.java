package ast;

import environment.Environment;

/**
 * @author Andrew Liang
 * @version 3.21.24
 * 
 * Handles assignment of variables to values
 */
public class Assignment extends Statement
{
    /**
     * variable name
     */
    private String var;
    /**
     * expression, value assigned to variable
     */
    private Expression exp;

    public Assignment(String inputVar, Expression inputExp)
    {
        var = inputVar;
        exp = inputExp;
    }

    /**
     * assign the variable the value of the expression in the environment
     * @param e environment which the variables will be in
     */
    public void exec(Environment e)
    {
        e.setVariable(var, exp.eval(e));
    }
}
